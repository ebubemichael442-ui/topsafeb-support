(() => {
 const cfg=window.TOPSAFEB_CONFIG||{};
 const client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabasePublishableKey);
 const $=id=>document.getElementById(id);
 let token=localStorage.getItem("topsafeb_support_token");
 if(!token){token=crypto.randomUUID();localStorage.setItem("topsafeb_support_token",token);}
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function load(){
  const {data,error}=await client.rpc("read_customer_messages",{p_token:token});
  if(error){$("status").textContent="Messages could not be loaded. Please refresh and try again.";return;}
  $("thread").innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender==='customer'?'mine':'theirs'}"><small>${m.sender==='customer'?'You':'TopSafeB Support'} · ${new Date(m.created_at).toLocaleString()}</small><div>${esc(m.message)}</div></div>`).join("")||'<p class="muted">Your messages and support replies will appear here.</p>';
 }
 $("sendBtn").addEventListener("click",async()=>{
  const name=$("customerName").value.trim(), message=$("message").value.trim();
  if(!name||!message){$("status").textContent="Enter your name and message.";return;}
  $("sendBtn").disabled=true;$("status").textContent="Sending…";
  const {error}=await client.rpc("send_customer_message",{p_name:name,p_token:token,p_message:message});
  $("sendBtn").disabled=false;
  if(error){$("status").textContent="Could not send your message. Please try again.";return;}
  $("message").value="";$("status").textContent="Message sent.";await load();
 });
 load();setInterval(load,12000);
})();
