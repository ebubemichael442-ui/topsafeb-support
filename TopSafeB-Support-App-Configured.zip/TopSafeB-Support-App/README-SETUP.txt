TOPSAFEB SUPPORT - SETUP

This is a static HTML/JavaScript starter configured with your new Supabase project.
It is not live until you publish the files to a static host.

1. In Supabase SQL Editor, run owner-setup.sql AFTER the first SQL script already run.
2. In Supabase Dashboard > Authentication > Users, create/ invite the owner account:
   ebubemichael442@gmail.com
   Set a strong password. If email confirmation is enabled, confirm the account.
3. Publish this folder to a static host that supports HTTPS (for example, a new GitHub Pages repository or Netlify site).
4. Customer page: /index.html
   Private owner sign-in: /admin.html
5. On iPhone, after deployment, open /admin.html in Safari > Share > Add to Home Screen.

SECURITY NOTES
- config.js contains only the browser-safe Supabase publishable key.
- Never put a Supabase secret/service_role key in these files.
- Owner RPCs check the authenticated email against owner_allowlist.
- Customers should not send passwords, one-time codes, card numbers or bank login details.
- Customer conversation access is based on a random token stored in that browser's local storage. Clearing browser storage loses access to that thread.
- This starter polls for updates; it does not send push notifications or email alerts.
- Test with a non-sensitive sample message before sharing publicly.
