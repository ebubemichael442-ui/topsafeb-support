(() => {
 const cfg=window.TOPSAFEB_CONFIG||{};
 const client=window.supabase.createClient(cfg.supabaseUrl,cfg.supabasePublishableKey);
 const $=id=>document.getElementById(id);let selected=null;
 const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function showSession(){
  const {data:{session}}=await client.auth.getSession();
  $("loginPanel").hidden=!!session;$("inboxPanel").hidden=!session;
  if(session) await loadConversations();
 }
 async function loadConversations(){
  const {data,error}=await client.rpc("owner_list_conversations");
  if(error){$("ownerStatus").textContent="Inbox access failed. Check the owner setup SQL and signed-in email.";return;}
  $("conversationList").innerHTML=(data||[]).map(c=>`<button class="conversation" data-id="${c.id}"><strong>${esc(c.customer_name)}</strong><small>${esc(c.last_message||"No messages")}</small><small>${new Date(c.last_message_at||c.created_at).toLocaleString()}</small></button>`).join("")||'<p class="muted">No customer messages yet.</p>';
  $("conversationList").querySelectorAll("[data-id]").forEach(b=>b.addEventListener("click",()=>openConversation(b.dataset.id,b.querySelector("strong").textContent)));
 }
 async function openConversation(id,name){
  selected=id;$("chatTitle").textContent=name;
  const {data,error}=await client.rpc("owner_read_messages",{p_conversation_id:id});
  if(error){$("ownerStatus").textContent="Could not open this conversation.";return;}
  $("ownerThread").innerHTML=(data||[]).map(m=>`<div class="bubble ${m.sender==='owner'?'mine':'theirs'}"><small>${m.sender==='owner'?'You':'Customer'} · ${new Date(m.created_at).toLocaleString()}</small><div>${esc(m.message)}</div></div>`).join("");
 }
 $("loginBtn").addEventListener("click",async()=>{
  $("loginStatus").textContent="Signing in…";
  const {error}=await client.auth.signInWithPassword({email:$("email").value.trim(),password:$("password").value});
  $("loginStatus").textContent=error?"Sign-in failed. Check your email and password.":"";
  if(!error) await showSession();
 });
 $("logoutBtn").addEventListener("click",async()=>{await client.auth.signOut();selected=null;await showSession();});
 $("replyBtn").addEventListener("click",async()=>{
  const message=$("replyText").value.trim();if(!selected||!message){$("ownerStatus").textContent="Select a conversation and enter a reply.";return;}
  $("replyBtn").disabled=true;
  const {error}=await client.rpc("owner_reply",{p_conversation_id:selected,p_message:message});
  $("replyBtn").disabled=false;
  if(error){$("ownerStatus").textContent="Reply failed. Check owner access.";return;}
  $("replyText").value="";$("ownerStatus").textContent="Reply sent.";await openConversation(selected,$("chatTitle").textContent);await loadConversations();
 });
 showSession();setInterval(async()=>{const {data:{session}}=await client.auth.getSession();if(session){await loadConversations();if(selected) await openConversation(selected,$("chatTitle").textContent);}},15000);
})();
