// TopSafeB Support: browser-safe Supabase configuration.
// The publishable key is intended for browser use. Never put a secret/service_role key here.
window.TOPSAFEB_CONFIG = {
  supabaseUrl: "https://iicalpeanrhouhelajhk.supabase.co",
  supabasePublishableKey: "sb_publishable_kdvNYeX4IBKb8pOtB7Ieog_rjRJRc_x"
};
