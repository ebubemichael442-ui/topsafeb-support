-- Run this SECOND SQL script after the initial database script.
-- It restricts owner inbox RPCs to this allowlisted owner email.
create table if not exists public.owner_allowlist (
  email text primary key
);
alter table public.owner_allowlist enable row level security;
revoke all on public.owner_allowlist from anon, authenticated;
insert into public.owner_allowlist(email)
values ('ebubemichael442@gmail.com')
on conflict (email) do nothing;

create or replace function public.is_topsafeb_owner()
returns boolean
language sql
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.owner_allowlist a
    where lower(a.email) = lower(coalesce(auth.jwt()->>'email',''))
  );
$$;
revoke all on function public.is_topsafeb_owner() from public;
grant execute on function public.is_topsafeb_owner() to authenticated;

create or replace function public.owner_list_conversations()
returns table(id uuid, customer_name text, created_at timestamptz, last_message text, last_message_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_topsafeb_owner() then raise exception 'Not authorized'; end if;
  return query
  select c.id, c.customer_name, c.created_at,
    (select m.message from public.messages m where m.conversation_id=c.id order by m.created_at desc limit 1),
    (select m.created_at from public.messages m where m.conversation_id=c.id order by m.created_at desc limit 1)
  from public.conversations c
  order by coalesce((select max(m.created_at) from public.messages m where m.conversation_id=c.id),c.created_at) desc;
end;
$$;
revoke all on function public.owner_list_conversations() from public;
grant execute on function public.owner_list_conversations() to authenticated;

create or replace function public.owner_read_messages(p_conversation_id uuid)
returns table(sender text, message text, created_at timestamptz)
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_topsafeb_owner() then raise exception 'Not authorized'; end if;
  return query select m.sender,m.message,m.created_at
    from public.messages m where m.conversation_id=p_conversation_id order by m.created_at;
end;
$$;
revoke all on function public.owner_read_messages(uuid) from public;
grant execute on function public.owner_read_messages(uuid) to authenticated;

create or replace function public.owner_reply(p_conversation_id uuid,p_message text)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  if not public.is_topsafeb_owner() then raise exception 'Not authorized'; end if;
  if length(trim(p_message)) < 1 or length(trim(p_message)) > 3000 then raise exception 'Invalid message'; end if;
  if not exists(select 1 from public.conversations where id=p_conversation_id) then raise exception 'Conversation not found'; end if;
  insert into public.messages(conversation_id,sender,message)
  values(p_conversation_id,'owner',trim(p_message));
end;
$$;
revoke all on function public.owner_reply(uuid,text) from public;
grant execute on function public.owner_reply(uuid,text) to authenticated;
